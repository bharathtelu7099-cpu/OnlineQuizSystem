# Online Quiz System (Student Version)

quiz_system/
│── main.py       # Entry point (menu-driven)
│── question.py   # Question class
│── quiz.py       # Quiz class (collection of questions)
│── student.py    # Student class
│── quiz_system.py# QuizSystem class (manages everything)
│── report.py     # Reporting functions
│── exceptions.py # Custom exceptions
│── utils.py      # Helper functions (id generation, validation)
│── data/
│   └── sample_data.json # Optional starter quiz
│── README.md            # Student instructions



## Problem Statement
Design a quiz platform where multiple-choice questions can be created. Students can attempt quizzes, and the system should evaluate scores.

## Topics Covered
- OOP (Question, Quiz, Student, QuizSystem classes)
- Dictionaries and Lists
- Exception Handling
- Reporting

## Step-by-Step Workflow
1. Implement Question class
2. Implement Quiz class
3. Implement Student class
4. Implement QuizSystem class
5. Add reporting functions
6. Build menu in main.py
